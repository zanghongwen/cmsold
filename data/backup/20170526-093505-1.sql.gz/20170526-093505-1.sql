-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 
-- Port     : 
-- Database : 
-- 
-- Part : #1
-- Date : 2017-05-26 09:35:05
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `admin`
-- -----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` char(32) NOT NULL,
  `nickname` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `lasttime` int(10) unsigned NOT NULL,
  `lastip` varchar(20) NOT NULL,
  `encrypt` char(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `admin`
-- -----------------------------
INSERT INTO `admin` VALUES ('1', 'admin', '8bd052acac520d66d9dd429e472f5249', 'admin', 'zanghongwen@163.com', '1495761464', '0.0.0.0', 'nsElcI');

-- -----------------------------
-- Table structure for `article`
-- -----------------------------
DROP TABLE IF EXISTS `article`;
CREATE TABLE `article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `inputtime` int(10) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `thumb` varchar(100) NOT NULL,
  `updatetime` int(10) unsigned NOT NULL,
  `catid` mediumint(8) unsigned NOT NULL,
  `description` varchar(200) NOT NULL,
  `keywords` varchar(50) NOT NULL,
  `url` varchar(100) NOT NULL,
  `listorder` smallint(5) unsigned NOT NULL,
  `username` varchar(20) NOT NULL,
  `posids` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `article`
-- -----------------------------
INSERT INTO `article` VALUES ('1', 'test标题', '1495761751', '1', '', '1495761751', '1', '描述：描述：描述：描述：描述：', 'test', '/cms/index.php/article/show.html?id=1', '0', 'admin', '{\"0\":\"2\"}');

-- -----------------------------
-- Table structure for `article_data`
-- -----------------------------
DROP TABLE IF EXISTS `article_data`;
CREATE TABLE `article_data` (
  `id` int(10) unsigned NOT NULL,
  `content` text NOT NULL,
  `gallery` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `article_data`
-- -----------------------------
INSERT INTO `article_data` VALUES ('1', '<p><span style="font-family: 微软雅黑; font-size: 14px; text-align: right; white-space: normal;">内容</span><span style="font-family: 微软雅黑; font-size: 14px; text-align: right; white-space: normal;">内容</span><span style="font-family: 微软雅黑; font-size: 14px; text-align: right; white-space: normal;">内容</span><span style="font-family: 微软雅黑; font-size: 14px; text-align: right; white-space: normal;">内容</span><span style="font-family: 微软雅黑; font-size: 14px; text-align: right; white-space: normal;">内容</span><span style="font-family: 微软雅黑; font-size: 14px; text-align: right; white-space: normal;">内容</span><span style="font-family: 微软雅黑; font-size: 14px; text-align: right; white-space: normal;">内容</span></p>', '');

-- -----------------------------
-- Table structure for `attachment`
-- -----------------------------
DROP TABLE IF EXISTS `attachment`;
CREATE TABLE `attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(100) NOT NULL,
  `filepath` varchar(200) NOT NULL,
  `fileext` varchar(10) NOT NULL,
  `filesize` int(10) NOT NULL,
  `inputtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `category`
-- -----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `catid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `catname` varchar(30) NOT NULL,
  `pid` mediumint(8) NOT NULL,
  `thumb` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `url` varchar(100) NOT NULL,
  `listorder` smallint(5) unsigned NOT NULL,
  `category` varchar(100) NOT NULL,
  `list` varchar(100) NOT NULL,
  `show` varchar(100) NOT NULL,
  `ispart` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ishidden` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `issend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `keywords` varchar(100) NOT NULL,
  PRIMARY KEY (`catid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `category`
-- -----------------------------
INSERT INTO `category` VALUES ('1', '栏目名称测试', '0', '', '', '/cms/index.php/category/lists.html?catid=1', '0', 'category.html', 'list.html', 'show.html', '0', '0', '1', '', '');
INSERT INTO `category` VALUES ('2', '随便', '0', '', '', '/cms/index.php/category/lists.html?catid=2', '0', 'category.html', 'list.html', 'show.html', '0', '0', '1', '', '');

-- -----------------------------
-- Table structure for `flink`
-- -----------------------------
DROP TABLE IF EXISTS `flink`;
CREATE TABLE `flink` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `url` varchar(200) NOT NULL,
  `logo` varchar(200) NOT NULL,
  `listorder` smallint(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `flink`
-- -----------------------------
INSERT INTO `flink` VALUES ('1', '网易', 'www.163.com', '', '0');

-- -----------------------------
-- Table structure for `guestbook`
-- -----------------------------
DROP TABLE IF EXISTS `guestbook`;
CREATE TABLE `guestbook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `addtime` int(10) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `name` varchar(20) NOT NULL,
  `qq` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  `replytime` int(10) unsigned NOT NULL,
  `replycontent` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `hits`
-- -----------------------------
DROP TABLE IF EXISTS `hits`;
CREATE TABLE `hits` (
  `hid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contentid` int(10) unsigned NOT NULL,
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `views` int(10) unsigned NOT NULL DEFAULT '0',
  `yesterdayviews` int(10) unsigned NOT NULL DEFAULT '0',
  `dayviews` int(10) unsigned NOT NULL DEFAULT '0',
  `weekviews` int(10) unsigned NOT NULL DEFAULT '0',
  `monthviews` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`hid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `hits`
-- -----------------------------
INSERT INTO `hits` VALUES ('1', '1', '1', '1', '0', '1', '1', '1', '1495761805');

-- -----------------------------
-- Table structure for `position`
-- -----------------------------
DROP TABLE IF EXISTS `position`;
CREATE TABLE `position` (
  `posid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(8) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `listorder` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`posid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `position`
-- -----------------------------
INSERT INTO `position` VALUES ('1', '0', '首页焦点图推荐', '0');
INSERT INTO `position` VALUES ('2', '0', '首页头条推荐', '0');

-- -----------------------------
-- Table structure for `position_data`
-- -----------------------------
DROP TABLE IF EXISTS `position_data`;
CREATE TABLE `position_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `posid` smallint(5) unsigned NOT NULL,
  `listorder` smallint(5) unsigned NOT NULL,
  `contentid` int(10) unsigned NOT NULL,
  `catid` mediumint(8) unsigned NOT NULL,
  `inputtime` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `position_data`
-- -----------------------------
INSERT INTO `position_data` VALUES ('1', '2', '0', '1', '1', '1495761751');

-- -----------------------------
-- Table structure for `register`
-- -----------------------------
DROP TABLE IF EXISTS `register`;
CREATE TABLE `register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `register`
-- -----------------------------
INSERT INTO `register` VALUES ('1', 'pennypang', 'penny', '', '');
INSERT INTO `register` VALUES ('3', '', '444', '33', '');
INSERT INTO `register` VALUES ('4', '', '444', '3333', 'abc');
INSERT INTO `register` VALUES ('5', 'adfdddddd', '444', '222', 'male');
INSERT INTO `register` VALUES ('6', 'adfdddddd', '444', '111', 'male');
INSERT INTO `register` VALUES ('7', '`12123123', '444', '2323', 'male');
INSERT INTO `register` VALUES ('8', 'qweqwe', '444', '', 'male');
INSERT INTO `register` VALUES ('9', 'qweqwe', '444', '333', 'male');
INSERT INTO `register` VALUES ('10', 'qweqwe', '444', '333', 'male');
INSERT INTO `register` VALUES ('11', 'landy', '73883', 'mary', 'female');
INSERT INTO `register` VALUES ('12', 'landy', '73883', 'mary', 'female');

-- -----------------------------
-- Table structure for `system`
-- -----------------------------
DROP TABLE IF EXISTS `system`;
CREATE TABLE `system` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `keywords` varchar(200) NOT NULL,
  `description` varchar(200) NOT NULL,
  `isthumb` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `width` smallint(5) unsigned NOT NULL DEFAULT '320',
  `height` smallint(5) unsigned NOT NULL DEFAULT '240',
  `iswater` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `pwater` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `daypoint` smallint(5) unsigned NOT NULL DEFAULT '0',
  `addpoint` smallint(5) unsigned NOT NULL DEFAULT '0',
  `delpoint` smallint(5) unsigned NOT NULL DEFAULT '0',
  `regpoint` smallint(5) unsigned NOT NULL DEFAULT '0',
  `template` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `system`
-- -----------------------------
INSERT INTO `system` VALUES ('1', 'Penny网', '娱乐, 文章, 休闲', 'Penny网Penny网Penny网Penny网Penny网我的网站', '1', '320', '240', '0', '0', '20', '5', '5', '500', 'default');

-- -----------------------------
-- Table structure for `tag`
-- -----------------------------
DROP TABLE IF EXISTS `tag`;
CREATE TABLE `tag` (
  `tagid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tag` varchar(100) NOT NULL,
  `count` int(11) NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL,
  PRIMARY KEY (`tagid`),
  KEY `keyword` (`tag`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tag`
-- -----------------------------
INSERT INTO `tag` VALUES ('1', 'test', '1', '1');

-- -----------------------------
-- Table structure for `tag_data`
-- -----------------------------
DROP TABLE IF EXISTS `tag_data`;
CREATE TABLE `tag_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tagid` int(10) unsigned NOT NULL DEFAULT '0',
  `contentid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tagid` (`tagid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `tag_data`
-- -----------------------------
INSERT INTO `tag_data` VALUES ('1', '1', '1');

-- -----------------------------
-- Table structure for `user`
-- -----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` char(32) NOT NULL,
  `lasttime` int(10) unsigned NOT NULL,
  `money` int(10) unsigned NOT NULL,
  `email` varchar(50) NOT NULL,
  `nickname` varchar(20) NOT NULL,
  `encrypt` char(6) NOT NULL,
  `lastip` varchar(20) NOT NULL,
  `regip` varchar(20) NOT NULL,
  `regtime` int(10) unsigned NOT NULL,
  `point` int(10) unsigned NOT NULL DEFAULT '0',
  `groupid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `headpic` varchar(100) NOT NULL,
  `islock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `user`
-- -----------------------------
INSERT INTO `user` VALUES ('1', 'test1', 'efa1226469bf4fc293a617fbdba62d8f', '1495377342', '0', 'zanghongwen@163.com', 'test1', 'jqwVeZ', '0.0.0.0', '0.0.0.0', '1495377313', '500', '0', '', '0');
INSERT INTO `user` VALUES ('2', 'penny', '', '0', '0', 'whypenny@163.com', '', '', '', '', '0', '0', '0', '', '0');
INSERT INTO `user` VALUES ('3', 'tom', '', '0', '0', '12@163.com', '', '', '', '', '0', '0', '0', '', '0');
INSERT INTO `user` VALUES ('4', 'steven', '', '0', '0', 'test@22.com', '', '', '', '', '0', '0', '0', '', '0');
INSERT INTO `user` VALUES ('5', 'steven', '', '0', '0', 'test@22.com', '', '', '', '', '0', '0', '0', '', '0');
INSERT INTO `user` VALUES ('6', 'steven', '', '0', '0', 'test@22.com', '', '', '', '', '0', '0', '0', '', '0');
INSERT INTO `user` VALUES ('7', '2323', '', '0', '0', 'test@22.com', '', '', '', '', '0', '0', '0', '', '0');
INSERT INTO `user` VALUES ('8', '2323', '', '0', '0', 'test@22.com', '', '', '', '', '0', '0', '0', '', '0');
INSERT INTO `user` VALUES ('9', '444', '', '0', '0', 'test@22.com', '', '', '', '', '0', '0', '0', '', '0');

-- -----------------------------
-- Table structure for `user_group`
-- -----------------------------
DROP TABLE IF EXISTS `user_group`;
CREATE TABLE `user_group` (
  `groupid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `point` int(10) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`groupid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `user_group`
-- -----------------------------
INSERT INTO `user_group` VALUES ('1', '初级会员', '1000', '0');
INSERT INTO `user_group` VALUES ('2', '中级会员', '2000', '0');
INSERT INTO `user_group` VALUES ('3', '高级会员', '3000', '0');
INSERT INTO `user_group` VALUES ('5', '超级会员', '10000', '0');
